# Spark-Streaming-Apache-Kafka-Apache-HBase
Spark Streaming example project which pulls messages from Kafka and write to HBase Table.
