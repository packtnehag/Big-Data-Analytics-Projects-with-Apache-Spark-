create 'sensors', 'data', 'alert', 'stats';

count 'sensors'
scan 'sensors'

-->when want to delete table
disable 'sensors'
drop 'sensors'

alter 'sensors', 'stats'