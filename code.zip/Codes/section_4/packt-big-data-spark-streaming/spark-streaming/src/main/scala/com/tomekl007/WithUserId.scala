package com.tomekl007

trait WithUserId {
  val userId: String
}

trait WithId {
  val id: String
}
